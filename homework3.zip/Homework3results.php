<?php
    $answer1 = $_POST['q1'];
    $answer2 = $_POST['q2'];
    $answer3 = $_POST['q3'];
    $answer4 = $_POST['q4'];
    $answer5 = $_POST['q5'];
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];

    $totalCorrect = 0;
    
    if ($answer1 == "Huron, Ontario, Michigan, Erie, Superior"){ $totalCorrect++; }
       
    if ($answer2 == " Missouri") { $totalCorrect++; }

    if (in_array(" Vermont",$answer3) && in_array(" Rhode Island",$answer3)) { $totalCorrect++; }

    if ($answer4 == " Rhode Island") { $totalCorrect++; }
        
    if ($answer5 == " Colorado") { $totalCorrect++; }

    echo $first." ".$last."<br>";
    $date = new DateTime();
    echo $date->format('Y-m-d H:i:s T')."<br><br>";

    echo $totalCorrect." / 5 Correct<br>";
    echo "Score: ".(($totalCorrect / 5)*100)."%<br><br>";
    if ($totalCorrect == 5) { echo "Congratulations! You got a perfect score!<br><br>"; }
    
    echo "<br>1. What are the 5 Great Lakes?<br><br>";
    if ($answer1 == "Huron, Ontario, Michigan, Erie, Superior"){ echo "Correct!<br>";}
    if ($answer1 !== "Huron, Ontario, Michigan, Erie, Superior"){ echo "Incorrect<br>";}
    echo "Your answer: ".$answer1."<br>";
    echo "The answer is: Huron, Ontario, Michigan, Erie, Superior<br><br><br>";

    echo "2. Which state's capital is Jefferson City?<br><br>";
    if ($answer2 == " Missouri"){ echo "Correct!<br>";}
    if ($answer2 !== " Missouri"){ echo "Incorrect<br>";}
    echo "Your answer: ".$answer2."<br>";
    echo "The answer is: Missouri<br><br><br>";

    echo "3. Which state(s) are in the New England region?<br><br>";
    if (in_array(" Vermont",$answer3) && in_array(" Rhode Island",$answer3)) { echo "Correct!<br>"; }
    else{ echo "Incorrect<br>";}
    echo "Your answer: ";
    foreach($answer3 as $selected) { echo $selected." "; }
    echo "<br>The answer is: Vermont and Rhode Island<br><br><br>";
    
    echo "4. Which is the smallest state?<br><br>";
    if ($answer4 == " Rhode Island") { echo "Correct!<br>"; }
    if ($answer4 !== " Rhode Island") { echo "Incorrect<br>"; }
    echo "Your answer: ".$answer4."<br>";
    echo "The answer is: Rhode Island<br><br><br>";
    
    echo "5. Which state has the longest continuous street in America, Colfax Avenue?<br><br>";
    if ($answer5 == " Colorado") { echo "Correct!<br>"; }
    if ($answer5 !== " Colorado") { echo "Incorrect<br>"; }
    echo "Your answer: ".$answer5."<br>";
    echo "The answer is: Colorado<br><br><br>"; 

    $filename = "/var/www/html/spring2019/jtz12/Homework3history.txt";
    $file = array_unique($filename);
    $content = file_get_contents($file);
    $results = $first." ".$last.' '.$date->format('Y-m-d H:i:s T').' '.$totalCorrect.' '.$answer1.' '.$answer2.' '.$answer3.' '.$answer4.' '.$answer5;
    $content .= $results.";";
    file_put_contents($filename, $content, FILE_APPEND | LOCK_EX);
?>