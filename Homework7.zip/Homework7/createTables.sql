CREATE TABLE `Category` (
  `categoryID` int(11) NOT NULL,
  `categoryTitle` varchar(45) DEFAULT NULL,
  `categoryDescription` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`categoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `Reply` (
  `replyID` int(11) NOT NULL AUTO_INCREMENT,
  `replyText` varchar(500) DEFAULT NULL,
  `replyDate` date DEFAULT NULL,
  `userID` int(11) NOT NULL,
  `topicID` int(11) NOT NULL,
  PRIMARY KEY (`replyID`),
  KEY `fk_Reply_User_idx` (`userID`),
  KEY `fk_Reply_Topic1_idx` (`topicID`),
  CONSTRAINT `fk_Reply_Topic1` FOREIGN KEY (`topicID`) REFERENCES `Topic` (`topicID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Reply_User` FOREIGN KEY (`userID`) REFERENCES `User` (`userID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

CREATE TABLE `Topic` (
  `topicID` int(11) NOT NULL AUTO_INCREMENT,
  `topicTitle` varchar(45) DEFAULT NULL,
  `topicDescription` varchar(200) DEFAULT NULL,
  `topicDate` date DEFAULT NULL,
  `userID` int(11) NOT NULL,
  `categoryID` int(11) NOT NULL,
  PRIMARY KEY (`topicID`),
  KEY `fk_Topic_User1_idx` (`userID`),
  KEY `fk_Topic_Category1_idx` (`categoryID`),
  CONSTRAINT `fk_Topic_Category1` FOREIGN KEY (`categoryID`) REFERENCES `Category` (`categoryID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Topic_User1` FOREIGN KEY (`userID`) REFERENCES `User` (`userID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

CREATE TABLE `User` (
  `userID` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
